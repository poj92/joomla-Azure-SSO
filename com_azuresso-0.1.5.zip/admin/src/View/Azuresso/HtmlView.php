<?php
namespace Joomla\Component\Azuresso\Administrator\View\Azuresso;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView;

class AzuressoView extends HtmlView
{
    public function display($tpl = null)
    {
        $this->renderDisplay($tpl);
    }
}
